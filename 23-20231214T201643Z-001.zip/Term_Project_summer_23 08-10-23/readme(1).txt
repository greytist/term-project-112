CMU Dating Simulator
(is it even possible!?)

about:

I created a game where you play as a CMU student, and you have to become friends with
someone in order to ask them out in 3 days time. There are two different characters
so there is some sort of variety. How the game works is that you have relationship 
stats with the other characters, and you have an intelligence stat for yourself.
You must answer trivia correctly during lecture to gain intelligence. You need a 
certain ammount of this to be able to win. The lecture questions are just random trivia
so they are kinda hard, so I added a feature where every night you gain smarts just 
from "studying" (going onto next day). The relationship stats come from 2 different
mechanics; the first is the ability to choose answer choices to things that the characters
say during the dialogue. Most of the time, 1 answer gives you points and the other takes
them away. The second mechanic is a minigame where you must bring la prima coffee to 
the character. This automatically improves your relationship with them. You need a 
certain amount of relationship with any character to win.
I tried to make the narration and dialogue as entertaining as I could without it being too
weird. Hope you enjoy!

How to run:

The file you want to run is called " main_file.py ". Most of the code is in here, so it is one
of the bigger files. After you run the main file, all you need to do is go ham smile

There are no external libraries.

There are no shortcut commands. Each minigame comes up at least twice. Be careful not to 
click through the dialogue too fast or you could miss something. (just like in real life!)